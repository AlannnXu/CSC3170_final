-- Retrieve the names and reward points of customers whose reward points are greater than a certain value:

SELECT customer_ID, reward_points FROM Customers WHERE reward_points > 100;
