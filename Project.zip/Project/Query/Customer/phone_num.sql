-- Retrieve all customer phone numbers
SELECT phone_number FROM Customers;
