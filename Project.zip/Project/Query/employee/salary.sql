-- employees in ascending order of salary

SELECT employee_ID, salary
FROM Employees
ORDER BY salary ASC;
