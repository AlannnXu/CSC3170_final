-- Get goods by brand:

SELECT * FROM Goods WHERE brand = 'brand_name';
