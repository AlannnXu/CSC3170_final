-- Get goods by price range: (need modify while using)

SELECT * FROM Goods WHERE price BETWEEN min_price AND max_price;
