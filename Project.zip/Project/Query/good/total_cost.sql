-- Get the total inventory cost:

SELECT SUM(inventory * cost) AS total_cost FROM Inventory;
