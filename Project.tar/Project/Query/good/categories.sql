-- Get goods by category:

SELECT * FROM Goods WHERE category = 'category_name';
