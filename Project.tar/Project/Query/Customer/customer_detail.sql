-- Retrieve the details of the customer with a specific ID:

SELECT * FROM Customers WHERE customer_ID = 000001;
