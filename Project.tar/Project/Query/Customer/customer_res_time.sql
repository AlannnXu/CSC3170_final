-- Retrieve the names of customers who registered on or after a certain date:

SELECT customer_ID FROM Customers WHERE registration_time >= '2019-01-01';
